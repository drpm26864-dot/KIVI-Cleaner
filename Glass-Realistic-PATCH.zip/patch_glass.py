#!/usr/bin/env python3
'''Glass 2.2.1 RU/New Year patch; original upstream project remains MIT licensed.

Run in a checkout of https://github.com/tlfares/GlassLauncher at tag v2.2.1:
    python3 patch_glass.py path/to/GlassLauncher

Six winter_XX.jpg files must be beside this script.
'''
from pathlib import Path
import sys
import re
import shutil
import xml.etree.ElementTree as ET

T = {'bt_connected_kind': 'Подключено · %s', 'bt_device': 'Устройство', 'bt_discover_failed': 'Не удалось выполнить поиск (геолокация?)', 'bt_discovering': 'Поиск устройств…', 'bt_forget_confirm': 'Нажмите OK ещё раз, чтобы удалить %s', 'bt_forget_failed': 'Не удалось удалить %s', 'bt_forgotten': 'Устройство %s удалено', 'bt_kind_audio': 'Аудиоустройство', 'bt_kind_computer': 'Компьютер', 'bt_kind_gamepad': 'Геймпад / клавиатура', 'bt_kind_phone': 'Телефон', 'bt_kind_remote': 'Пульт', 'bt_my_devices': 'Мои устройства', 'bt_none_paired': 'Нет сопряжённых устройств', 'bt_not_connected_kind': 'Не подключено · %s', 'bt_ok_to_pair': 'OK — подключить · %s', 'bt_other_devices': 'Другие устройства', 'bt_pair_failed': 'Не удалось сопрячь с %s', 'bt_paired': '%s подключено', 'bt_pairing': 'Сопряжение с %s…', 'bt_permission_missing': 'Нет разрешения на Bluetooth', 'bt_protected': 'Управление пультами и контроллерами — в настройках системы', 'bt_search': 'Искать устройства', 'bt_searching': 'Поиск…', 'bt_system_settings': 'Устройства в настройках системы', 'bt_the_device': 'устройство', 'cc_anim_adb': 'Включить через ADB', 'cc_anim_fast': 'Быстро ×%.1f', 'cc_anim_normal': 'Обычная', 'cc_anim_off': 'Выключена', 'cc_animations': 'Анимация', 'cc_hidden_apps': 'Скрытые приложения', 'cc_hidden_count': '%d · OK — показать', 'cc_hidden_none': 'Нет', 'cc_memory': 'Оперативная память', 'cc_no_devices': 'Устройств нет', 'cc_not_connected': 'Не подключено', 'cc_off': 'Выкл.', 'cc_storage': 'Хранилище', 'cc_system': 'Система', 'cc_top_shelf_app': 'Цвета приложений', 'cc_unavailable': 'Недоступно', 'cc_wallpaper': 'Обои', 'greeting_afternoon': 'Добрый день', 'greeting_afternoon_name': 'Добрый день, %s', 'greeting_evening': 'Добрый вечер', 'greeting_evening_name': 'Добрый вечер, %s', 'greeting_morning': 'Доброе утро', 'greeting_morning_name': 'Доброе утро, %s', 'hint_move': 'Перемещайте «%s» стрелками · OK — готово', 'menu_hide': 'Скрыть', 'menu_info': 'О приложении', 'menu_move': 'Переместить', 'section_about': 'О Glass', 'section_accessibility': 'Специальные возможности', 'section_all': 'Все настройки', 'section_apps': 'Приложения', 'section_devices': 'Устройства', 'section_display': 'Экран и звук', 'section_network': 'Сеть', 'top_settings': 'Настройки', 'usage_free': 'Свободно: %s', 'usage_free_of': 'Свободно %1$s из %2$s', 'wallpaper_aurora': 'Северное сияние', 'wallpaper_dusk': 'Сумерки', 'wallpaper_graphite': 'Графит', 'wallpaper_liquid': 'Переливы', 'wallpaper_photo': 'Фото', 'wifi_connect_failed': 'Не удалось подключиться к %s', 'wifi_connected': 'Подключено', 'wifi_connected_ip': 'Подключено · %s', 'wifi_connecting': 'Подключение к %s…', 'wifi_location_off': 'Включите геолокацию в настройках системы для поиска сетей', 'wifi_networks': 'Сети Wi-Fi', 'wifi_none_found': 'Сети не найдены', 'wifi_password': 'Пароль', 'wifi_password_for': 'для «%s»', 'wifi_password_hint': 'Подтвердите на клавиатуре · Назад — отмена', 'wifi_rescan': 'Повторить поиск', 'wifi_save_failed': 'Не удалось сохранить сеть', 'wifi_saved': 'Сохранено', 'wifi_scan_no_location': 'Нет разрешения на геолокацию для поиска сетей', 'wifi_searching': 'Поиск сетей…', 'wifi_system_settings': 'Системные настройки сети', 'wallpaper_new_year': 'Новый год'}

# This variant does not use the older single seasonal wallpaper resource.
T.pop('wallpaper_new_year', None)

if len(sys.argv) != 2:
    sys.exit('Usage: python3 patch_glass.py <path-to-GlassLauncher-v2.2.1>')
root = Path(sys.argv[1]).resolve()
home = root/'app/src/main/java/com/fares/glass/ui/HomeScreen.kt'
wallpapers = root/'app/src/main/java/com/fares/glass/gfx/Wallpapers.kt'
repo = root/'app/src/main/java/com/fares/glass/data/AppRepository.kt'
build = root/'app/build.gradle.kts'
strings = root/'app/src/main/res/values/strings.xml'
ru = root/'app/src/main/res/values-ru/strings.xml'
assets = root/'app/src/main/assets'

for f in (home, wallpapers, repo, build, strings):
    if not f.is_file():
        sys.exit('No upstream Glass v2.2.1 file: '+str(f))

def patch(path, old, new):
    s=path.read_text(encoding='utf-8')
    if s.count(old)!=1:
        sys.exit(f'Patch incompatible with current source: {path.name}, found {s.count(old)} occurrences')
    path.write_text(s.replace(old,new),encoding='utf-8')

# Dock stays; lower rows do not draw on the initial home screen.
# Moving the focus down immediately renders the full grid as before.
patch(home,
      'if (i / Metrics.COLS in visibleRows) key(entry.pkg) {',
      'if (i / Metrics.COLS in visibleRows && (row != 0 || i < Metrics.COLS)) key(entry.pkg) {')

assets.mkdir(parents=True,exist_ok=True)

# Bundle six distinct winter wallpapers instead of the 4 original abstract presets.
images = [f"winter_{i:02}.jpg" for i in range(1, 7)]
for filename in images:
    source = Path(__file__).with_name(filename)
    if not source.is_file() or source.stat().st_size < 10_000:
        sys.exit('Missing bundled wallpaper: ' + filename)
    shutil.copy2(source, assets / filename)

s = wallpapers.read_text(encoding='utf-8')
start = s.find('    fun count(context: Context)')
end = s.find('    private fun render(', start)
if start < 0 or end < 0:
    sys.exit('Unexpected upstream Wallpapers.kt layout')
replacement = r'''    private const val WINTER_COUNT = 6

    fun count(context: Context): Int = WINTER_COUNT + if (hasCustom(context)) 1 else 0

    fun name(context: Context, index: Int): String = when {
        index in 0 until WINTER_COUNT -> context.getString(
            when (index) {
                0 -> R.string.wallpaper_winter_01
                1 -> R.string.wallpaper_winter_02
                2 -> R.string.wallpaper_winter_03
                3 -> R.string.wallpaper_winter_04
                4 -> R.string.wallpaper_winter_05
                else -> R.string.wallpaper_winter_06
            }
        )
        else -> context.getString(R.string.wallpaper_photo)
    }

    fun load(context: Context, index: Int): Bitmap {
        if (index in 0 until WINTER_COUNT) {
            context.assets.open("winter_%02d.jpg".format(java.util.Locale.US, index + 1)).use { stream ->
                BitmapFactory.decodeStream(stream)?.let { return it }
            }
        }
        if (index == WINTER_COUNT && hasCustom(context)) {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(customFile.path, opts)
            var sample = 1
            while (opts.outWidth / (sample * 2) >= 1920) sample *= 2
            BitmapFactory.decodeFile(customFile.path, BitmapFactory.Options().apply { inSampleSize = sample })
                ?.let { return it }
        }
        return render(presets[index % presets.size], index)
    }

'''
wallpapers.write_text(s[:start] + replacement + s[end:], encoding='utf-8')

patch(repo,
      'var wallpaperIndex by mutableIntStateOf(prefs.getInt("wallpaper", 0))\n        private set',
      '''var wallpaperIndex by mutableIntStateOf(
        if (prefs.getBoolean("holiday_dock_six_2026_initialized", false)) prefs.getInt("wallpaper", 0) else 0
    )
        private set

    init {
        if (!prefs.getBoolean("holiday_dock_six_2026_initialized", false)) {
            prefs.edit().putInt("wallpaper", 0).putBoolean("holiday_dock_six_2026_initialized", true).apply()
        }
    }''')

patch(build, 'versionCode = 5', 'versionCode = 8')
patch(build, 'versionName = "2.2.1"', 'versionName = "2.2.1-RU-NewYear-Dock-6"')

keys = [f'wallpaper_winter_{i:02}' for i in range(1, 7)]
english = ['Northern Lights', 'Moonlit Forest', 'Winter City', 'Cozy Fireplace', 'Golden Lights', 'Glass Ornaments']
s = strings.read_text(encoding='utf-8')
for name, value in zip(keys, english):
    if f'<string name="{name}">' in s:
        sys.exit('String already exists: ' + name)
    s = s.replace('</resources>', f'    <string name="{name}">{value}</string>\n</resources>')
strings.write_text(s, encoding='utf-8')
T.update(dict(zip(keys, ['Северное сияние', 'Лунный лес', 'Зимний город', 'Уют у камина', 'Золотые огни', 'Стеклянные игрушки'])))

# Light-duty animated snow and twinkling lights, on home screen only.
patch(home,
      'import androidx.compose.foundation.Image',
      '''import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image''')
patch(home,
      'import androidx.compose.animation.core.animateFloatAsState',
      '''import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode''')
patch(home,
      'import androidx.compose.ui.Alignment',
      '''import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset''')
patch(home,
      '    val row = state.row',
      '''    val row = state.row
    val winterMotion = rememberInfiniteTransition(label = "winterMotion")
    val snowProgress by winterMotion.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(22000, easing = LinearEasing)), label = "snowDrift"
    )
    val twinkle by winterMotion.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400), repeatMode = RepeatMode.Reverse),
        label = "winterLights"
    )''')
patch(home,
      '        // Glass dock under the first row; it fades out when you move into the grid.',
      '''        // Winter visual layer: sparse slow snow and subtle fairy lights.
        // Canvas never intercepts remote-control input.
        if (row == 0 && state.mode == Mode.Browse) {
            Canvas(Modifier.fillMaxSize()) {
                val widthPx = size.width
                val heightPx = size.height
                for (i in 0 until 26) {
                    val baseX = ((i * 137 + 31) % 997) / 997f
                    val baseY = ((i * 193 + 61) % 991) / 991f
                    val x = ((baseX + snowProgress * (0.035f + (i % 4) * 0.006f)) % 1f) * widthPx
                    val y = ((baseY + snowProgress * (0.10f + (i % 5) * 0.012f)) % 1f) * heightPx
                    drawCircle(
                        color = Color.White.copy(alpha = 0.10f + (i % 5) * 0.035f),
                        radius = (0.7f + (i % 3) * 0.42f).dp.toPx(),
                        center = Offset(x, y)
                    )
                }
                for (i in 0 until 8) {
                    val x = widthPx * (0.63f + i * 0.041f)
                    val y = heightPx * (0.050f + (i % 3) * 0.009f)
                    val glow = if (i % 2 == 0) twinkle else 1f - twinkle
                    drawCircle(
                        color = Color(0xFFFFE9AC).copy(alpha = 0.12f + glow * 0.33f),
                        radius = 1.8.dp.toPx(),
                        center = Offset(x, y)
                    )
                }
            }
        }

        // Glass dock under the first row; it fades out when you move into the grid.''')

# Real Android resource translations (not bytecode patching).
base=ET.parse(strings).getroot()
base_strings={e.get('name') for e in base.findall('string')}
if set(T)-base_strings:
    sys.exit('Translation refers to missing keys: '+str(set(T)-base_strings))
resources=ET.Element('resources')
for element in base.findall('string'):
    name=element.get('name')
    if name in T:
        e=ET.SubElement(resources, 'string', {'name':name})
        e.text=T[name]
plurals=ET.SubElement(resources, 'plurals', {'name':'cc_connected_count'})
for quantity,text in [
    ('one','%d подключённое устройство'),
    ('few','%d подключённых устройства'),
    ('many','%d подключённых устройств'),
    ('other','%d подключённых устройств'),
]:
    e=ET.SubElement(plurals,'item',{'quantity':quantity})
    e.text=text
ET.indent(resources,space='    ')
ru.parent.mkdir(parents=True,exist_ok=True)
ET.ElementTree(resources).write(ru,encoding='utf-8',xml_declaration=True)

# Verify the patch contents before any network-dependent build steps.
assert 'row != 0 || i < Metrics.COLS' in home.read_text(encoding='utf-8')
assert 'wallpaper_winter_01' in wallpapers.read_text(encoding='utf-8')
assert 'holiday_dock_six_2026_initialized' in repo.read_text(encoding='utf-8')
assert len(ET.parse(ru).getroot().findall('string'))==len(T)
assert len(ET.parse(ru).getroot().findall('plurals'))==1
print('PATCH OK: dock clean; six scenic wallpapers; snowfall; glow; RU:',len(T))
