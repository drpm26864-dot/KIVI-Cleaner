#!/usr/bin/env python3
'''Apply Realistic Edition after patch_glass.py on upstream Glass v2.2.1.'''
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

root = Path(sys.argv[1]).resolve()
ui = root/'app/src/main/java/com/fares/glass/ui'
home = ui/'HomeScreen.kt'
control = ui/'ControlCenter.kt'
repo = root/'app/src/main/java/com/fares/glass/data/AppRepository.kt'
build = root/'app/build.gradle.kts'
strings = root/'app/src/main/res/values/strings.xml'
ru = root/'app/src/main/res/values-ru/strings.xml'

def replace_once(path,old,new):
    s = path.read_text(encoding='utf-8')
    if s.count(old)!=1:
        raise ValueError(f'Expected ONE anchor in {path.name}: {old[:90]!r}; found {s.count(old)}')
    path.write_text(s.replace(old,new),encoding='utf-8')

s=home.read_text(encoding='utf-8')
start='    val winterMotion = rememberInfiniteTransition(label = "winterMotion")'
end='    val scrollTarget ='
assert s.count(start)==1 and s.count(end)==1
s=s[:s.index(start)]+s[s.index(end,s.index(start)):]
start='        // Winter visual layer: sparse slow snow and subtle fairy lights.'
end='        // Glass dock under the first row; it fades out when you move into the grid.'
assert s.count(start)==1 and s.count(end)==1
s=s[:s.index(start)]+'''        WinterAtmosphere(
            snowLevel = repo.snowIntensity,
            glowEnabled = repo.garlandEnabled,
            wallpaperIndex = repo.wallpaperIndex,
            active = row == 0 && state.mode != Mode.Control,
        )

'''+s[s.index(end,s.index(start)):]
home.write_text(s,encoding='utf-8')
(ui/'WinterAtmosphere.kt').write_bytes(Path(__file__).with_name('WinterAtmosphere.kt').read_bytes())

replace_once(repo,
    '    var topShelf by mutableStateOf(prefs.getBoolean("topShelf", false))',
    '''    var topShelf by mutableStateOf(prefs.getBoolean("topShelf", false))
    var snowIntensity by mutableIntStateOf(prefs.getInt("winter_snow_level", 1).coerceIn(0, 2))
        private set
    var garlandEnabled by mutableStateOf(prefs.getBoolean("winter_garland_enabled", true))
        private set''')
replace_once(repo,
    '    fun toggleTopShelf() {',
    '''    fun cycleSnowIntensity() {
        snowIntensity = (snowIntensity + 1) % 3
        prefs.edit().putInt("winter_snow_level", snowIntensity).apply()
    }

    fun toggleGarland() {
        garlandEnabled = !garlandEnabled
        prefs.edit().putBoolean("winter_garland_enabled", garlandEnabled).apply()
    }

    fun toggleTopShelf() {''')

replace_once(control,
    'enum class CcPage { Main, Wifi, Bluetooth }',
    'enum class CcPage { Main, Wifi, Bluetooth, Holiday }')
replace_once(control,
    'data class Action(val title: String, val icon: ImageVector) : Line { override val key get() = "action" }',
    'data class Action(val title: String, val icon: ImageVector, val stableKey: String = "action") : Line { override val key get() = stableKey }')
replace_once(control,
    'index = when (target) { CcPage.Wifi -> 0; CcPage.Bluetooth -> 1; CcPage.Main -> 0 }',
    'index = when (target) { CcPage.Wifi -> 0; CcPage.Bluetooth -> 1; CcPage.Main -> 0; CcPage.Holiday -> 4 }')
replace_once(control,
    'Tile(Icons.Rounded.ViewCarousel, "Top Shelf", str(if (repo.topShelf) R.string.cc_top_shelf_app else R.string.cc_wallpaper), repo.topShelf, Purple),',
    'Tile(Icons.Rounded.ViewCarousel, str(R.string.holiday_effects), str(R.string.holiday_snow), repo.snowIntensity > 0 || repo.garlandEnabled, Purple),')
replace_once(control,
    '            4 -> repo.toggleTopShelf()',
    '            4 -> { page = CcPage.Holiday; rowKey = "holiday_snow" }')
replace_once(control,
    '        CcPage.Wifi -> buildList {',
    '''        CcPage.Holiday -> listOf(
            Line.Action(str(R.string.holiday_snow) + ": " + str(when (repo.snowIntensity) {
                0 -> R.string.holiday_level_off
                1 -> R.string.holiday_level_low
                else -> R.string.holiday_level_normal
            }), Icons.Rounded.Animation, "holiday_snow"),
            Line.Action(str(R.string.holiday_garland) + ": " + str(if (repo.garlandEnabled) R.string.holiday_level_on else R.string.holiday_level_off), Icons.Rounded.Wallpaper, "holiday_garland"),
            Line.Action("Top Shelf: " + str(if (repo.topShelf) R.string.holiday_level_on else R.string.holiday_level_off), Icons.Rounded.ViewCarousel, "holiday_top_shelf")
        )
        CcPage.Wifi -> buildList {''')
replace_once(control,
    '            is Line.Action -> if (page == CcPage.Wifi) wifi.scan() else bt.discover()',
    '''            is Line.Action -> when (page) {
                CcPage.Wifi -> wifi.scan()
                CcPage.Bluetooth -> bt.discover()
                CcPage.Holiday -> when (r.key) {
                    "holiday_snow" -> repo.cycleSnowIntensity()
                    "holiday_garland" -> repo.toggleGarland()
                    "holiday_top_shelf" -> repo.toggleTopShelf()
                    else -> Unit
                }
                else -> Unit
            }''')
replace_once(control,
    'BasicText(if (p == CcPage.Wifi) "Wi-Fi" else "Bluetooth", style = txt(White, 24.sp, FontWeight.Bold))',
    '''BasicText(when (p) {
                    CcPage.Wifi -> "Wi-Fi"
                    CcPage.Bluetooth -> "Bluetooth"
                    CcPage.Holiday -> str(R.string.holiday_effects)
                    else -> ""
                }, style = txt(White, 24.sp, FontWeight.Bold))''')

# Localize the new settings and the renamed six photo themes.
new_en={
 'holiday_effects':'Holiday effects', 'holiday_snow':'Snowfall', 'holiday_garland':'Fairy lights',
 'holiday_level_on':'On','holiday_level_off':'Off','holiday_level_low':'Light','holiday_level_normal':'Normal',
 'wallpaper_winter_01':'Winter Cabin','wallpaper_winter_02':'Winter City',
 'wallpaper_winter_03':'Cozy Fireplace','wallpaper_winter_04':'Moonlit Forest',
 'wallpaper_winter_05':'Glass Ornaments','wallpaper_winter_06':'Mountain Evening'
}
new_ru={
 'holiday_effects':'Новогодние эффекты','holiday_snow':'Снегопад','holiday_garland':'Гирлянда',
 'holiday_level_on':'Вкл.','holiday_level_off':'Выкл.','holiday_level_low':'Слабый','holiday_level_normal':'Обычный',
 'wallpaper_winter_01':'Зимний домик','wallpaper_winter_02':'Зимний город',
 'wallpaper_winter_03':'Уют у камина','wallpaper_winter_04':'Лунный лес',
 'wallpaper_winter_05':'Стеклянные украшения','wallpaper_winter_06':'Горный вечер'
}
for path,translations in ((strings,new_en),(ru,new_ru)):
    tree=ET.parse(path)
    base=tree.getroot()
    for name,value in translations.items():
        hit=base.find(f"string[@name='{name}']")
        if hit is None:
            hit=ET.SubElement(base,'string',{'name':name})
        hit.text=value
    ET.indent(tree,space='    ')
    tree.write(path,encoding='utf-8',xml_declaration=True)
replace_once(build,'versionCode = 8','versionCode = 10')
replace_once(build,'versionName = "2.2.1-RU-NewYear-Dock-6"','versionName = "2.2.1-RU-NewYear-Realistic"')

# Regression checks: old overlay and dot animation must not reappear.
s=home.read_text(encoding='utf-8')
assert 'winterMotion' not in s and 'snowDrift' not in s
assert 'Winter visual layer: sparse slow snow' not in s
assert s.count('WinterAtmosphere(')==1
assert '&& (row != 0 || i < Metrics.COLS)' in s
wc=(ui/'WinterAtmosphere.kt').read_text(encoding='utf-8')
assert 'fallingSnowTimeline' in wc and 'naturalLightTwinkle' in wc
assert 'if (!active' in wc and 'lineHeight' in wc
assert all(f'holiday_{name}' in control.read_text() for name in ['effects','snow','garland'])
assert 'holiday_snow' in control.read_text()
print('REALISTIC PATCH OK: no old dots or fake central bulb row, two snow depths, photo glows, effects settings')
