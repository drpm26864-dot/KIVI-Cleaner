package com.fares.glass.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * Subtle, persistent atmosphere drawn BEHIND the home dock and controls.
 * No extra row of bulbs, no transition flash, no remote input interception.
 * Small particle count for the older Android 7.1 TV GPU.
 */
@Composable
fun WinterAtmosphere(snowLevel: Int, glowEnabled: Boolean, wallpaperIndex: Int, active: Boolean) {
    val timeline = rememberInfiniteTransition(label = "winterAtmosphere")
    val snowPhase by timeline.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(30000, easing = LinearEasing)),
        label = "fallingSnowTimeline"
    )
    val glowPhase by timeline.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(7400, easing = LinearEasing)),
        label = "naturalLightTwinkle"
    )
    if (!active || (snowLevel == 0 && !glowEnabled)) return
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val twoPi = 6.2831853f
        if (snowLevel > 0) {
            val nearCount = if (snowLevel == 1) 11 else 18
            val farCount = if (snowLevel == 1) 14 else 24
            // Never reset on input: both layers travel the entire screen continuously.
            for (layer in 0..1) {
                val count = if (layer == 0) farCount else nearCount
                for (i in 0 until count) {
                    val seed = i + 113 * layer
                    val x0 = ((seed * 239 + 37) % 1013) / 1013f
                    val y0 = ((seed * 383 + 71) % 1009) / 1009f
                    val speed = if (layer == 0) 1.08f + (i % 4) * 0.15f else 1.67f + (i % 5) * 0.20f
                    val phase = (snowPhase * speed + y0) % 1f
                    // Fade near wrap to prevent popping at the top/bottom edges.
                    val edge = (phase * 25f).coerceAtMost(1f) * ((1f-phase)*25f).coerceAtMost(1f)
                    val gust = sin(snowPhase * twoPi * (0.45f + layer * 0.25f) + i * 1.17f)
                    val x = ((x0 + gust * 0.010f + 1f) % 1f) * w
                    val y = phase * h
                    val alpha = edge * (if (layer == 0) 0.21f else 0.40f) * (0.7f + 0.3f * (i % 3) / 2f)
                    val r = (if (layer == 0) 0.75f else 1.20f).dp.toPx()
                    val lineHeight = if (layer == 0) 2.0f else 3.5f
                    drawLine(
                        Color(0xFFE8F0F6).copy(alpha = alpha),
                        Offset(x - r * 0.18f, y - lineHeight.dp.toPx()),
                        Offset(x, y + r),
                        strokeWidth = r * 1.1f,
                    )
                }
            }
        }
        if (glowEnabled) {
            // The warm illuminations below line up with *existing* photo lights.
            // No drawn wiring or artificial light row across the landscape.
            val anchors = when (wallpaperIndex) {
                0 -> arrayOf(Offset(0.738f,0.548f),Offset(0.767f,0.520f),Offset(0.807f,0.534f)) // cabin windows
                1 -> arrayOf(Offset(0.065f,0.275f),Offset(0.195f,0.184f),Offset(0.325f,0.205f)) // street lamps
                2 -> arrayOf(Offset(0.151f,0.182f),Offset(0.228f,0.176f),Offset(0.333f,0.169f)) // mantel garland
                3 -> arrayOf(Offset(0.110f,0.096f),Offset(0.180f,0.075f),Offset(0.253f,0.083f)) // pine lights
                4 -> arrayOf(Offset(0.220f,0.080f),Offset(0.370f,0.057f),Offset(0.580f,0.074f)) // glass decorations
                5 -> arrayOf(Offset(0.081f,0.116f),Offset(0.152f,0.101f),Offset(0.852f,0.525f)) // mountain cottage
                else -> emptyArray<Offset>() // never draw synthetic lights on the user's photo
            }
            for (j in anchors.indices) {
                val pulse = 0.5f + 0.5f * sin(glowPhase * twoPi + j * 1.93f)
                val p = Offset(anchors[j].x*w, anchors[j].y*h)
                val brightness = 0.025f + 0.045f * pulse // gentle, not blinking dots
                drawCircle(Color(0xFFFFD5A1).copy(alpha=brightness), radius=15.dp.toPx(), center=p)
                drawCircle(Color(0xFFFFE8C7).copy(alpha=brightness*1.4f), radius=5.dp.toPx(), center=p)
            }
        }
    }
}
